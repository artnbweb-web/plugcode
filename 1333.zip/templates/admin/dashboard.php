<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// آمار کلی
$total_users = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users}");
$total_referrals = $wpdb->get_var("SELECT COUNT(*) FROM Shahkar_referral_log");
$total_rewards = $wpdb->get_var("SELECT COALESCE(SUM(vr_amount), 0) FROM Shahkar_referral_trx");
$total_balance = $wpdb->get_var("SELECT COALESCE(SUM(vw_balance), 0) FROM Shahkar_wallet");

// آمار امروز
$today_start = strtotime('today midnight');
$today_trx = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM Shahkar_referral_trx WHERE vr_date >= %d", $today_start
));
$today_rewards = $wpdb->get_var($wpdb->prepare(
    "SELECT COALESCE(SUM(vr_amount), 0) FROM Shahkar_referral_trx WHERE vr_date >= %d", $today_start
));

// آمار 7 روز
$week_start = strtotime('-7 days');
$week_trx = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM Shahkar_referral_trx WHERE vr_date >= %d", $week_start
));

// کاربران برتر
$top_users = $wpdb->get_results("
    SELECT 
        vr_inviter_user as user_id,
        COUNT(*) as ref_count,
        SUM(vr_amount) as total_earned,
        u.display_name
    FROM Shahkar_referral_trx t
    LEFT JOIN {$wpdb->users} u ON t.vr_inviter_user = u.ID
    GROUP BY vr_inviter_user
    ORDER BY total_earned DESC
    LIMIT 5
");

// آخرین تراکنش‌ها
$recent_trx = $wpdb->get_results("
    SELECT t.*, u1.display_name as user_name, u2.display_name as ref_name
    FROM Shahkar_referral_trx t
    LEFT JOIN {$wpdb->users} u1 ON t.vr_inviter_user = u1.ID
    LEFT JOIN {$wpdb->users} u2 ON t.vr_current_user = u2.ID
    ORDER BY t.vr_id DESC
    LIMIT 10
");

// آمار نمودار 7 روز
$chart_data = [];
for ($i = 6; $i >= 0; $i--) {
    $date = strtotime("-$i days midnight");
    $date_end = strtotime("-$i days midnight +1 day");
    
    $amount = $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(vr_amount), 0) FROM Shahkar_referral_trx WHERE vr_date >= %d AND vr_date < %d",
        $date, $date_end
    ));
    
    $chart_data[] = [
        'date' => date('m/d', $date),
        'amount' => floatval($amount)
    ];
}
?>

<div class="wrap">
    <div class="srs-admin-dashboard">
        <div class="srs-admin-header">
            <h1>📊 داشبورد سیستم پاداش شاهکار</h1>
            <p>مدیریت جامع سیستم پاداش، کش‌بک و رفرال</p>
        </div>

        <!-- کارت‌های آماری -->
        <div class="srs-stats-grid">
            <div class="srs-stat-card srs-stat-card--primary">
                <div class="srs-stat-card__icon">👥</div>
                <div class="srs-stat-card__content">
                    <h3>کل کاربران</h3>
                    <p class="srs-stat-card__value"><?php echo number_format($total_users); ?></p>
                    <span class="srs-stat-card__label">کاربر فعال</span>
                </div>
            </div>
            
            <div class="srs-stat-card srs-stat-card--success">
                <div class="srs-stat-card__icon">🔗</div>
                <div class="srs-stat-card__content">
                    <h3>کل رفرال‌ها</h3>
                    <p class="srs-stat-card__value"><?php echo number_format($total_referrals); ?></p>
                    <span class="srs-stat-card__label">دعوت موفق</span>
                </div>
            </div>
            
            <div class="srs-stat-card srs-stat-card--warning">
                <div class="srs-stat-card__icon">💰</div>
                <div class="srs-stat-card__content">
                    <h3>کل پاداش‌ها</h3>
                    <p class="srs-stat-card__value"><?php echo number_format($total_rewards); ?></p>
                    <span class="srs-stat-card__label">تومان پرداختی</span>
                </div>
            </div>
            
            <div class="srs-stat-card srs-stat-card--info">
                <div class="srs-stat-card__icon">💳</div>
                <div class="srs-stat-card__content">
                    <h3>موجودی کیف پول‌ها</h3>
                    <p class="srs-stat-card__value"><?php echo number_format($total_balance); ?></p>
                    <span class="srs-stat-card__label">تومان</span>
                </div>
            </div>
        </div>

        <!-- آمار امروز و هفته -->
        <div class="srs-quick-stats">
            <div class="srs-quick-stat">
                <span class="srs-quick-stat__icon">📅</span>
                <div class="srs-quick-stat__content">
                    <strong><?php echo number_format($today_trx); ?></strong>
                    <span>تراکنش امروز</span>
                </div>
            </div>
            <div class="srs-quick-stat">
                <span class="srs-quick-stat__icon">💵</span>
                <div class="srs-quick-stat__content">
                    <strong><?php echo number_format($today_rewards); ?></strong>
                    <span>پاداش امروز (تومان)</span>
                </div>
            </div>
            <div class="srs-quick-stat">
                <span class="srs-quick-stat__icon">📊</span>
                <div class="srs-quick-stat__content">
                    <strong><?php echo number_format($week_trx); ?></strong>
                    <span>تراکنش 7 روز اخیر</span>
                </div>
            </div>
        </div>

        <!-- نمودار -->
        <div class="srs-chart-section">
            <div class="srs-card">
                <div class="srs-card__header">
                    <h2>📈 نمودار پاداش‌ها (7 روز اخیر)</h2>
                </div>
                <div class="srs-card__body">
                    <canvas id="srsChart" width="400" height="120"></canvas>
                </div>
            </div>
        </div>

        <!-- دو ستونه -->
        <div class="srs-two-columns">
            <!-- کاربران برتر -->
            <div class="srs-card">
                <div class="srs-card__header">
                    <h2>🏆 کاربران برتر</h2>
                </div>
                <div class="srs-card__body">
                    <?php if ($top_users): ?>
                        <div class="srs-top-users-list">
                            <?php foreach ($top_users as $index => $user): ?>
                                <div class="srs-top-user">
                                    <span class="srs-top-user__rank">#<?php echo $index + 1; ?></span>
                                    <div class="srs-top-user__info">
                                        <strong><?php echo esc_html($user->display_name); ?></strong>
                                        <small><?php echo $user->ref_count; ?> زیرمجموعه</small>
                                    </div>
                                    <span class="srs-top-user__amount"><?php echo number_format($user->total_earned); ?> تومان</span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="srs-empty-msg">هنوز کاربری ثبت نشده</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- آخرین تراکنش‌ها -->
            <div class="srs-card">
                <div class="srs-card__header">
                    <h2>📋 آخرین تراکنش‌ها</h2>
                    <a href="<?php echo admin_url('admin.php?page=shahkar-reward-transactions'); ?>" class="srs-link">مشاهده همه →</a>
                </div>
                <div class="srs-card__body">
                    <?php if ($recent_trx): ?>
                        <div class="srs-recent-trx-list">
                            <?php 
                            $type_labels = [0 => 'دعوت', 1 => 'اولین خرید', 2 => 'پاداش خرید'];
                            foreach ($recent_trx as $trx): 
                            ?>
                                <div class="srs-recent-trx">
                                    <div class="srs-recent-trx__icon">💰</div>
                                    <div class="srs-recent-trx__info">
                                        <strong><?php echo esc_html($trx->user_name); ?></strong>
                                        <small><?php echo $type_labels[$trx->vr_type] ?? 'پاداش'; ?></small>
                                    </div>
                                    <span class="srs-recent-trx__amount">+<?php echo number_format($trx->vr_amount); ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="srs-empty-msg">هنوز تراکنشی ثبت نشده</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script>
var ctx = document.getElementById('srsChart');
if (ctx) {
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_column($chart_data, 'date')); ?>,
            datasets: [{
                label: 'مبلغ پاداش (تومان)',
                data: <?php echo json_encode(array_column($chart_data, 'amount')); ?>,
                borderColor: '#6366f1',
                backgroundColor: 'rgba(99, 102, 241, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
}
</script>

<style>
.srs-admin-dashboard {
    background: #f5f5f5;
    padding: 20px;
    margin: -20px -20px 0 -40px;
}
.srs-admin-header {
    margin-bottom: 30px;
}
.srs-admin-header h1 {
    margin: 0 0 5px 0;
}
.srs-admin-header p {
    color: #666;
    margin: 0;
}
.srs-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 20px;
    margin-bottom: 20px;
}
.srs-stat-card {
    background: white;
    border-radius: 12px;
    padding: 25px;
    display: flex;
    align-items: center;
    gap: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    border-right: 4px solid;
    transition: transform 0.3s;
}
.srs-stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(0,0,0,0.12);
}
.srs-stat-card--primary { border-color: #6366f1; }
.srs-stat-card--success { border-color: #10b981; }
.srs-stat-card--warning { border-color: #f59e0b; }
.srs-stat-card--info { border-color: #3b82f6; }
.srs-stat-card__icon {
    font-size: 48px;
}
.srs-stat-card__content h3 {
    margin: 0 0 5px 0;
    font-size: 14px;
    color: #666;
}
.srs-stat-card__value {
    font-size: 32px;
    font-weight: bold;
    margin: 0;
    color: #1f2937;
}
.srs-stat-card__label {
    font-size: 12px;
    color: #999;
}
.srs-quick-stats {
    display: flex;
    gap: 15px;
    margin-bottom: 20px;
}
.srs-quick-stat {
    background: white;
    border-radius: 8px;
    padding: 15px 20px;
    display: flex;
    align-items: center;
    gap: 15px;
    flex: 1;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
}
.srs-quick-stat__icon {
    font-size: 32px;
}
.srs-quick-stat__content strong {
    display: block;
    font-size: 20px;
    color: #1f2937;
}
.srs-quick-stat__content span {
    font-size: 12px;
    color: #666;
}
.srs-chart-section {
    margin-bottom: 20px;
}
.srs-card {
    background: white;
    border-radius: 12px;
    padding: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}
.srs-card__header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 2px solid #f5f5f5;
}
.srs-card__header h2 {
    margin: 0;
    font-size: 18px;
}
.srs-link {
    color: #6366f1;
    text-decoration: none;
    font-weight: 600;
}
.srs-two-columns {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}
.srs-top-users-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}
.srs-top-user {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 12px;
    background: #f9fafb;
    border-radius: 8px;
}
.srs-top-user__rank {
    font-size: 20px;
    font-weight: bold;
    color: #6366f1;
    min-width: 30px;
}
.srs-top-user__info {
    flex: 1;
}
.srs-top-user__info strong {
    display: block;
    margin-bottom: 3px;
}
.srs-top-user__info small {
    color: #666;
    font-size: 12px;
}
.srs-top-user__amount {
    font-weight: bold;
    color: #10b981;
}
.srs-recent-trx-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}
.srs-recent-trx {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px;
    background: #f9fafb;
    border-radius: 6px;
}
.srs-recent-trx__icon {
    font-size: 24px;
}
.srs-recent-trx__info {
    flex: 1;
}
.srs-recent-trx__info strong {
    display: block;
    font-size: 14px;
}
.srs-recent-trx__info small {
    font-size: 12px;
    color: #666;
}
.srs-recent-trx__amount {
    font-weight: bold;
    color: #10b981;
    font-size: 14px;
}
.srs-empty-msg {
    text-align: center;
    color: #999;
    padding: 30px;
}
@media (max-width: 1024px) {
    .srs-two-columns {
        grid-template-columns: 1fr;
    }
}
</style>