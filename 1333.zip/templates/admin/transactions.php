<?php
if (!defined('ABSPATH')) exit;
?>

<div class="wrap">
    <div class="srs-admin-wrapper">
        <h1>📊 مدیریت تراکنش‌ها</h1>
        
        <?php if (!empty($transactions)): ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th width="60">شناسه</th>
                        <th>کاربر دریافت‌کننده</th>
                        <th>کاربر دعوت‌شده</th>
                        <th>مبلغ</th>
                        <th>نوع</th>
                        <th>تاریخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $admin_lang = get_option('Shahkar_admin_selected_lang', 'fa');
                    
                    foreach ($transactions as $trans): 
                        $type_labels = [0 => 'دعوت', 1 => 'اولین خرید', 2 => 'پاداش خرید'];
                        $type_label = $type_labels[$trans->type] ?? 'نامشخص';
                        
                        $timestamp = intval($trans->date);
                        if ($admin_lang == 'fa' && class_exists('ShahkarJdate\jdate')) {
                            $date_str = ShahkarJdate\jdate("Y/m/d H:i", $timestamp, '', '', 'en');
                        } else {
                            $date_str = date('Y/m/d H:i', $timestamp);
                        }
                    ?>
                        <tr>
                            <td><strong>#<?php echo $trans->id; ?></strong></td>
                            <td>
                                <?php if ($trans->user_name): ?>
                                    <strong><?php echo esc_html($trans->user_name); ?></strong><br>
                                    <small>ID: <?php echo $trans->user_id; ?></small>
                                <?php else: ?>
                                    کاربر #<?php echo $trans->user_id; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($trans->ref_user_name): ?>
                                    <?php echo esc_html($trans->ref_user_name); ?><br>
                                    <small>ID: <?php echo $trans->ref_user_id; ?></small>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><strong style="color: #10b981;"><?php echo number_format($trans->amount); ?> تومان</strong></td>
                            <td><span class="srs-badge"><?php echo $type_label; ?></span></td>
                            <td><?php echo $date_str; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="srs-empty-state">
                <p>هیچ تراکنشی یافت نشد</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.srs-badge {
    display: inline-block;
    padding: 4px 10px;
    background: #e0e7ff;
    color: #4f46e5;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
}
</style>