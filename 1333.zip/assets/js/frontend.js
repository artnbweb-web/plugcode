jQuery(document).ready(function($) {
    var dailyClaimInProgress = false;
    
    $('#srs-claim-daily-btn').on('click', function(e) {
        e.preventDefault();
        
        // جلوگیری از کلیک مجدد
        if (dailyClaimInProgress) {
            return false;
        }
        
        var btn = $(this);
        var originalText = btn.html();
        
        // غیرفعال کردن دکمه
        dailyClaimInProgress = true;
        btn.prop('disabled', true).css('opacity', '0.6').html('⏳ در حال پردازش...');
        
        $.ajax({
            url: srsData.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'srs_claim_daily',
                nonce: srsData.nonce
            },
            success: function(response) {
                if (response.success) {
                    // نمایش پیام موفقیت
                    btn.html('✓ دریافت شد').css({
                        'background': '#10b981',
                        'color': 'white'
                    });
                    
                    // نمایش alert
                    alert(response.data.message);
                    
                    // رفرش صفحه بعد از 1 ثانیه
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    // نمایش خطا
                    alert(response.data.message || 'خطا در دریافت پاداش');
                    
                    // فعال کردن مجدد دکمه
                    btn.prop('disabled', false).css('opacity', '1').html(originalText);
                    dailyClaimInProgress = false;
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                alert('خطا در ارتباط با سرور. لطفا دوباره تلاش کنید.');
                
                // فعال کردن مجدد دکمه
                btn.prop('disabled', false).css('opacity', '1').html(originalText);
                dailyClaimInProgress = false;
            }
        });
        
        return false;
    });
});